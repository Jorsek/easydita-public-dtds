
# README for the flat map specialization

Use the flat map specialization for content meant to be uploaded into a ticketing system, such as Zendesk.

The flat map specialization automatically applies @chunk to map section. This forces the system to create a single output document from that section.

## Flat Map components

-   **Map category**

    The `<mapcategory>` element is a specialization ot `<topichead>`. You must provide a navigation title \(`<navtitle>`\). You can have only one `<mapcategory>` element in a flat map `<flatmap>`.

-   **Map section**

    The `<mapsection>` element is also a specialization of `<topichead>`. You must provide a `<navtitle>`. Additionally, the `chunk` attribute \(@chunk\) is set to to-content by default; you cannot change this. You can use one or more `<mapsection>` elements in <mapcategory>. `<mapsection>` can contain <topicref> and `<mapsection>`.

-   **Topic reference**

    The `<topicref>` element is not specialized. The only difference is that `<topicref>` must be in a map section. You cannot add it to a map category.


